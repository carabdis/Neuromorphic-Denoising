import random
import numpy as np
x=[]
for i in range(100):
    a=np.random.normal(loc=0.0, scale=1.0, size=None)
    x.append(a)
print(x)